from Personaje import Personaje

class Arquero(Personaje):
    def __init__(self, nombre, vida, precision=30):
        super().__init__(nombre, vida)
        self.precision = precision  # Atributo único del arquero

    def atacar(self):
        print(f"🏹 {self.nombre} (Arquero) dispara una lluvia de flechas haciendo {self.precision} de daño.")
        return self.precision