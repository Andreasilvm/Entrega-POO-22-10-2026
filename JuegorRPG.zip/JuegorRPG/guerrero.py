from Personaje import Personaje

class Guerrero(Personaje):
    def __init__(self, nombre, vida, fuerza=35):
        super().__init__(nombre, vida)
        self.fuerza = fuerza  # Atributo único del guerrero

    def atacar(self):
        print(f"⚔️ {self.nombre} (Guerrero) usa su espada y realiza un daño crítico de {self.fuerza}.")
        return self.fuerza