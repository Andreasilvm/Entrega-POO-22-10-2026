from Personaje import Personaje

class Mago(Personaje):
    def __init__(self, nombre, vida, poder_magico=45):
        super().__init__(nombre, vida)
        self.poder_magico = poder_magico  # Atributo único del mago

    def atacar(self):
        print(f"🔮 {self.nombre} (Mago) invoca una poderosa bola de fuego haciendo {self.poder_magico} de daño.")
        return self.poder_magico