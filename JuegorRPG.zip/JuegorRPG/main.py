

from guerrero import Guerrero
from mago import Mago
from arquero import Arquero

if __name__ == "__main__":
    print("=========================================")
    print("   🎮 ¡BIENVENIDO AL JUEGO RPG ! 🎮   ")
    print("=========================================")
    
    # 1. Creación personalizada de personajes con input()
    print("\n[Paso 1] Crea a tus héroes:")
    nombre_g = input("🔹 Ingresa el nombre de tu Guerrero: ")
    nombre_m = input("🔹 Ingresa el nombre de tu Mago: ")
    nombre_a = input("🔹 Ingresa el nombre de tu Arquero: ")

    # Instanciamos los objetos
    heroe1 = Guerrero(nombre_g, 120)
    heroe2 = Mago(nombre_m, 80)
    heroe3 = Arquero(nombre_a, 90)

    # Variables de control del juego
    vida_equipo = 150  # Puntos de vida colectivos del equipo
    pociones = 2       # Cantidad de pociones curativas disponibles

    # 2. Selección del enemigo a enfrentar mision
    print("\n[Paso 2] Elige tu misión:")
    print("1. Goblin Explorador (Vida: 60)")
    print("2. Orco Berserker (Vida: 120)")
    print("3. Dragón Oscuro (Vida: 200)")
    
    eleccion_enemigo = input("Selecciona el monstruo a enfrentar (1-3): ")
    
    if eleccion_enemigo == "1":
        nombre_enemigo = "Goblin Explorador"
        vida_enemigo = 60
    elif eleccion_enemigo == "2":
        nombre_enemigo = "Orco Berserker"
        vida_enemigo = 120
    else:
        nombre_enemigo = "Dragón Oscuro"
        vida_enemigo = 200

    print(f"\n⚠️ ¡Un salvaje {nombre_enemigo} aparece con {vida_enemigo} puntos de vida!")

    # 3. Bucle principal de combate interactivo con más opciones
    en_combate = True
    while en_combate and vida_enemigo > 0 and vida_equipo > 0:
        print("\n-------------------------------------------------")
        print(f"🎯 ENEMIGO: {nombre_enemigo} (Vida: {vida_enemigo})")
        print(f"🛡️ ESTADO EQUIPO: Vida = {vida_equipo} | 🧪 Pociones = {pociones}")
        print("-------------------------------------------------")
        print("¿Qué acción deseas realizar?")
        print(f"1. Atacar con el Guerrero ({heroe1.name if hasattr(heroe1, 'name') else heroe1.nombre})")
        print(f"2. Atacar con el Mago ({heroe2.nombre})")
        print(f"3. Atacar con el Arquero ({heroe3.nombre})")
        print("4. 🔥 ¡Ataque combinado de los 3 héroes!")
        print(f"5.🧪 Usar poción de curación (Quedan: {pociones})")
        print("6. 🛡️ Activar postura defensiva (Reducir contraataque)")
        print("7. 🏃 Huir de la batalla")
        
        accion = input("\nElige una opción (1-7): ")

        # Control de daño del enemigo por cada turno que pasa
        daño_enemigo = 20 if eleccion_enemigo != "3" else 35

        if accion == "1":
            print(f"\n⚔️ ¡Turno de {heroe1.nombre}!")
            heroe1.atacar()
            vida_enemigo -= 35
        elif accion == "2":
            print(f"\n🔮 ¡Turno de {heroe2.nombre}!")
            heroe2.atacar()
            vida_enemigo -= 45
        elif accion == "3":
            print(f"\n🏹 ¡Turno de {heroe3.nombre}!")
            heroe3.atacar()
            vida_enemigo -= 30
        elif accion == "4":
            print("\n🔥 ¡LOS TRES HÉROES ATACAN AL UNÍSONO! 🔥")
            heroe1.atacar()
            heroe2.atacar()
            heroe3.atacar()
            vida_enemigo -= 110
        elif accion == "5":
            if pociones > 0:
                vida_equipo += 40
                pociones -= 1
                print(f"\n✨ ¡Has usado una poción! La vida del equipo sube a {vida_equipo}. Pociones restantes: {pociones}")
                continue # Salta el contraataque del enemigo porque usaron el turno en curarse
            else:
                print("\n❌ ¡No te quedan pociones! Perdiste el turno.")
        elif accion == "6":
            print(f"\n🛡️ ¡El equipo adopta una postura defensiva! El {nombre_enemigo} no logra hacer daño crítico este turno.")
            daño_enemigo = 5 # Daño reducido
        elif accion == "7":
            print("\n💨 ¡Has decidido huir COBARDEMENTE de la batalla! Fin del juego.")
            en_combate = False
            break
        else:
            print("\n❌ Opción inválida. ¡Pierdes tu turno por distraído!")

        # Verificamos si el enemigo fue derrotado
        if vida_enemigo <= 0:
            print("\n=========================================")
            print(f"🏆 ¡VICTORIA! Has derrotado al {nombre_enemigo}.")
            print("=========================================")
            en_combate = False
            break

        # Contraataque del enemigo al equipo
        vida_equipo -= daño_enemigo
        print(f"💥 ¡El {nombre_enemigo} contraataca y causa {daño_enemigo} de daño al equipo!")
        print(f"👉 Al {nombre_enemigo} le quedan {vida_enemigo} de vida | Tu equipo tiene {vida_equipo} de vida.")

        if vida_equipo <= 0:
            print("\n=========================================")
            print(f"💀 ¡DERROTA! Tu equipo ha caído ante el {nombre_enemigo}.")
            print("=========================================")
            en_combate = False

    print("\n¡Gracias por jugar a este RPG ---creadora andre!")

    


