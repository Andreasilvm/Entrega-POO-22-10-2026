# 1. Definimos la clase padre llamada Operacion (tal como está en la parte de arriba del diagrama)
class Operacion:
    
    # 2. Creamos el constructor (__init__) que recibe los dos números obligatorios del diagrama
    def __init__(self, numero1, numero2):
        self.numero1 = numero1  # 3. Guardamos el primer número dentro del objeto actual (self)
        self.numero2 = numero2  # 4. Guardamos el segundo número dentro del objeto actual (self)

    # 5. Definimos el método calcular() general que el diagrama exige en la clase Operacion
    def calcular(self):
        pass  # 6. 'pass' significa que aquí no hacemos nada todavía, las clases hijas lo van a rellenar

# 7. Creamos la clase hija 'Suma' que hereda de 'Operacion' (poniéndola entre paréntesis)
class Suma(Operacion):
    
    # 8. Sobrescribimos el método calcular() específicamente para la suma
    def calcular(self):
        return self.numero1 + self.numero2  # 9. Retornamos la suma de los dos atributos heredados

# 10. Creamos la clase hija 'Resta' que también hereda de 'Operacion'
class Resta(Operacion):
    
    # 11. Sobrescribimos el método calcular() para la resta
    def calcular(self):
        return self.numero1 - self.numero2  # 12. Retornamos la resta del primer número menos el segundo

# 13. Creamos la clase hija 'Multiplicacion' heredando de 'Operacion'
class Multiplicacion(Operacion):
    
    # 14. Sobrescribimos el método calcular() para la multiplicación
    def calcular(self):
        return self.numero1 * self.numero2  # 15. Retornamos el producto de ambos números

# 16. Creamos la clase hija 'Division' heredando de 'Operacion'
class Division(Operacion):
    
    # 17. Sobrescribimos el método calcular() para la división
    def calcular(self):
        # 18. Validamos con un if que el divisor (numero2) no sea cero para evitar errores de sistema
        if self.numero2 != 0:
            return self.numero1 / self.numero2  # 19. Si no es cero, hacemos la división normal
        else:
            return "Error: No se puede dividir entre cero"  # 20. Si es cero, devolvemos un mensaje de error

# 21. Comprobamos si estamos ejecutando este archivo directamente en la computadora
if __name__ == "__main__":
    
    print("=== CALCULADORA CON POO ===")  # 22. Imprimimos un título en la consola para el usuario
    
    # 23. Pedimos el primer número y lo convertimos a float (decimal / double del diagrama)
    n1 = float(input("Ingresa el primer número: "))
    
    # 24. Pedimos el segundo número y también lo convertimos a float
    n2 = float(input("Ingresa el segundo número: "))

    # 25. Creamos un objeto de tipo Suma enviándole los dos números ingresados
    op_suma = Suma(n1, n2)
    
    # 26. Creamos un objeto de tipo Resta con los mismos números
    op_resta = Resta(n1, n2)
    
    # 27. Creamos un objeto de tipo Multiplicacion
    op_mult = Multiplicacion(n1, n2)
    
    # 28. Creamos un objeto de tipo Division
    op_div = Division(n1, n2)

    # 29. Llamamos al método .calcular() del objeto suma e imprimimos el resultado
    print(f"Suma: {op_suma.calcular()}")
    
    # 30. Llamamos al método .calcular() del objeto resta e imprimimos el resultado
    print(f"Resta: {op_resta.calcular()}")
    
    # 31. Llamamos al método .calcular() del objeto multiplicación e imprimimos
    print(f"Multiplicación: {op_mult.calcular()}")
    
    # 32. Llamamos al método .calcular() del objeto división e imprimimos su respuesta
    print(f"División: {op_div.calcular()}")