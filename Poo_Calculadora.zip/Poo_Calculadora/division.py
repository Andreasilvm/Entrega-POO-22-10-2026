# division.py
from operacion import Operacion

class Division(Operacion):
    """Clase hija para la división con validación."""
    
    def calcular(self):
        if self.numero2 != 0:
            return self.numero1 / self.numero2
        else:
            return "Error: No se puede dividir entre cero"  