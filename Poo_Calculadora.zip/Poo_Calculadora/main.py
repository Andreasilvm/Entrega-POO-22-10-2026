# main.py
from operaciones import Suma, Resta, Multiplicacion, Division

if __name__ == "__main__":
    print("=== CALCULADORA CON POO ===")
    
    n1 = float(input("Ingresa el primer número: "))
    n2 = float(input("Ingresa el segundo número: "))

    op_suma = Suma(n1, n2)
    op_resta = Resta(n1, n2)
    op_mult = Multiplicacion(n1, n2)
    op_div = Division(n1, n2)

    print(f"Suma: {op_suma.calcular()}")
    print(f"Resta: {op_resta.calcular()}")
    print(f"Multiplicación: {op_mult.calcular()}")
    print(f"División: {op_div.calcular()}")