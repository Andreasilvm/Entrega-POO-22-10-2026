# multiplicacion.py
from operacion import Operacion

class Multiplicacion(Operacion):
    """Clase hija para la multiplicación."""
    
    def calcular(self):
        return self.numero1 * self.numero2