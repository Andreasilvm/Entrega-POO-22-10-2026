# operaciones.py

# Clase Padre
class Operacion:
    def __init__(self, numero1, numero2):
        self.numero1 = numero1
        self.numero2 = numero2

    def calcular(self):
        pass

# Clases Hijas
class Suma(Operacion):
    def calcular(self):
        return self.numero1 + self.numero2

class Resta(Operacion):
    def calcular(self):
        return self.numero1 - self.numero2

class Multiplicacion(Operacion):
    def calcular(self):
        return self.numero1 * self.numero2

class Division(Operacion):
    def calcular(self):
        if self.numero2 != 0:
            return self.numero1 / self.numero2
        else:
            return "Error: No se puede dividir entre cero"