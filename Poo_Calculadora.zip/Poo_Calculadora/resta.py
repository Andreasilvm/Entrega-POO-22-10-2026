# resta.py
from operacion import Operacion

class Resta(Operacion):
    """Clase hija para la resta."""
    
    def calcular(self):
        return self.numero1 - self.numero2
    