# Asegúrate de que esté así en tu archivo suma.py:
from operacion import Operacion

class Suma(Operacion):
    def calcular(self):
        return self.numero1 + self.numero2